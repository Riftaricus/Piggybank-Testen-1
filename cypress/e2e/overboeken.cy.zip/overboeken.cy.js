describe('Overboeken geld', () => {
  it('passes', () => {
    cy.visit('http://localhost:3001')
    cy.get('.login__account').contains("Melvin").click()
    cy.contains("Overboeken").click()
    cy.get('select[name="toaccount"]')
      .select('Sara Ravestein')
    cy.get('input[id="amount"]').type(99.99)
    cy.get('textarea[name="description"]').type("This is a test")
    cy.get('button[type="submit"]').click()

    cy.get('div.alert')
      .should('contain.text', 'Het is gelukt om € 99.99 over te maken!')
  })
})